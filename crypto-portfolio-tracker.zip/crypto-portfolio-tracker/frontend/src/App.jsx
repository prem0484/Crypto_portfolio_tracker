import React, { useEffect, useMemo, useState } from 'react'

const fmt = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' })
const pct = (x) => `${(x * 100).toFixed(2)}%`

async function fetchJSON(url, options) {
  const r = await fetch(url, options)
  if (!r.ok) throw new Error(`HTTP ${r.status}`)
  return await r.json()
}

export default function App() {
  const [coins, setCoins] = useState([])
  const [holdings, setHoldings] = useState([])
  const [prices, setPrices] = useState({})
  const [form, setForm] = useState({ symbol: 'BTC', amount: '', costBasis: '' })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    Promise.all([
      fetchJSON('/api/coins'),
      fetchJSON('/api/holdings')
    ]).then(([c, h]) => {
      setCoins(c)
      setHoldings(h)
    }).catch(e => setError(String(e))).finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!coins.length) return
    const ids = coins.map(c => c.id).join(',')
    fetchJSON(`/api/prices?ids=${encodeURIComponent(ids)}`)
      .then(setPrices)
      .catch(e => setError(String(e)))
  }, [coins])

  const totals = useMemo(() => {
    let value = 0, cost = 0, dayChange = 0
    for (const h of holdings) {
      const coin = coins.find(c => c.symbol === h.symbol)
      if (!coin || !prices[coin.id]) continue
      const price = prices[coin.id].usd
      const change = prices[coin.id].usd_24h_change / 100
      value += price * h.amount
      cost += (h.costBasis || 0) * h.amount
      dayChange += (price * change) * h.amount
    }
    const pl = value - cost
    const plPct = cost > 0 ? (pl / cost) : 0
    const dayPct = value > 0 ? (dayChange / value) : 0
    return { value, cost, pl, plPct, dayChange, dayPct }
  }, [holdings, coins, prices])

  const addHolding = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const body = {
        symbol: form.symbol,
        amount: parseFloat(form.amount || 0),
        costBasis: parseFloat(form.costBasis || 0)
      }
      const created = await fetchJSON('/api/holdings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body)
      })
      setHoldings(prev => [created, ...prev])
      setForm({ symbol: form.symbol, amount: '', costBasis: '' })
    } catch (e) {
      setError(String(e))
    }
  }

  const updateHolding = async (id, patch) => {
    const h = holdings.find(x => x.id === id)
    const body = { ...h, ...patch }
    await fetchJSON(`/api/holdings/${id}`, {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    })
    setHoldings(prev => prev.map(x => x.id === id ? body : x))
  }

  const removeHolding = async (id) => {
    await fetchJSON(`/api/holdings/${id}`, { method: 'DELETE' })
    setHoldings(prev => prev.filter(x => x.id !== id))
  }

  if (loading) return <div className="container"><div className="card">Loading…</div></div>
  return (
    <div className="container">
      <h1>Crypto Portfolio Tracker</h1>
      <p><small>Track holdings, live prices, and P&amp;L. Backend proxy uses CoinGecko.</small></p>

      <div className="kpi">
        <div className="k">
          <div>Total Value</div>
          <h2>{fmt.format(totals.value || 0)}</h2>
        </div>
        <div className="k">
          <div>Unrealized P&amp;L</div>
          <h2>{fmt.format(totals.pl || 0)} <span className="badge">{pct(totals.plPct || 0)}</span></h2>
        </div>
        <div className="k">
          <div>24h Change</div>
          <h2>{fmt.format(totals.dayChange || 0)} <span className="badge">{pct(totals.dayPct || 0)}</span></h2>
        </div>
      </div>

      <hr />

      <div className="card vstack">
        <h3>Add Holding</h3>
        <form onSubmit={addHolding} className="vstack">
          <div className="hstack">
            <select value={form.symbol} onChange={e => setForm(f => ({ ...f, symbol: e.target.value }))}>
              {coins.map(c => <option key={c.symbol} value={c.symbol}>{c.symbol}</option>)}
            </select>
            <input className="input" type="number" step="any" placeholder="Amount" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
            <input className="input" type="number" step="any" placeholder="Cost Basis (USD)" value={form.costBasis} onChange={e => setForm(f => ({ ...f, costBasis: e.target.value }))} />
            <button className="button" type="submit">Add</button>
          </div>
          {error && <div className="badge">{error}</div>}
        </form>
      </div>

      <hr />

      <div className="card vstack">
        <h3>Holdings</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Symbol</th>
              <th>Amount</th>
              <th>Price</th>
              <th>Value</th>
              <th>Cost/Unit</th>
              <th>P&amp;L</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {holdings.map(h => {
              const coin = coins.find(c => c.symbol === h.symbol)
              const price = coin && prices[coin.id] ? prices[coin.id].usd : 0
              const value = price * h.amount
              const cost = (h.costBasis || 0) * h.amount
              const pl = value - cost
              const plPct = cost > 0 ? (pl / cost) : 0
              return (
                <tr key={h.id}>
                  <td>{h.symbol}</td>
                  <td>
                    <input className="input" type="number" step="any" value={h.amount}
                      onChange={e => updateHolding(h.id, { amount: parseFloat(e.target.value || 0) })} />
                  </td>
                  <td>{fmt.format(price)}</td>
                  <td>{fmt.format(value)}</td>
                  <td>
                    <input className="input" type="number" step="any" value={h.costBasis}
                      onChange={e => updateHolding(h.id, { costBasis: parseFloat(e.target.value || 0) })} />
                  </td>
                  <td>{fmt.format(pl)} <span className="badge">{pct(plPct)}</span></td>
                  <td>
                    <button className="button" onClick={() => removeHolding(h.id)}>Delete</button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {holdings.length === 0 && <small>No holdings yet—add one above.</small>}
      </div>

      <footer>
        <p>Built with React, Vite, Express, and SQLite. Prices via CoinGecko.</p>
      </footer>
    </div>
  )
}
