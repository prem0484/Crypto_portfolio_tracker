# Crypto Portfolio Tracker (React + Node.js + SQLite)

A clean, full-stack web application to **track your crypto portfolio** with live prices, holdings, and P&L.

- **Frontend:** React (Vite) + fetch API
- **Backend:** Node.js + Express + SQLite (better-sqlite3)
- **Features:**
  - Add/edit/delete holdings (symbol, amount, optional cost basis)
  - Live prices via CoinGecko (proxied through the backend)
  - Auto-calculates position value and unrealized P&L
  - Simple, modern UI, responsive

## Quick Start

### 1) Backend
```bash
cd backend
npm install
npm run dev
```
Backend will run at `http://localhost:4000`.

### 2) Frontend
```bash
cd ../frontend
npm install
npm run dev
```
Frontend will run at `http://localhost:5173` and proxy API to the backend (already configured).

> Tip: Keep both servers running in two terminals.

## API Overview

- `GET /api/coins` → list of supported coins (symbol → CoinGecko id)
- `GET /api/holdings` → all holdings
- `POST /api/holdings` → create `{ symbol, amount, costBasis }`
- `PUT /api/holdings/:id` → update a holding
- `DELETE /api/holdings/:id` → delete a holding
- `GET /api/prices?ids=bitcoin,ethereum` → price data from CoinGecko

## Tech Notes

- **Database:** The SQLite DB file (`portfolio.db`) is created automatically in the backend folder.
- **Symbols Supported:** BTC, ETH, BNB, XRP, DOGE, SOL, ADA, MATIC, DOT, LTC, SHIB (easy to extend in `coins.js`).
- **Adding More Coins:** Edit `backend/coins.js` to add `{ symbol, id }`. Symbol must be unique.

## Build for Production

```bash
# build frontend
cd frontend
npm run build

# serve dist with any static server or integrate with your own setup
```

## License
MIT
