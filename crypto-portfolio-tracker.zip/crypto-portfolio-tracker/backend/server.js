import express from "express";
import cors from "cors";
import morgan from "morgan";
import fetch from "node-fetch";
import db from "./db.js";
import { COIN_MAP } from "./coins.js";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// --- Helpers ---
const symbolToId = (symbol) => {
  const entry = COIN_MAP.find(c => c.symbol.toUpperCase() === symbol.toUpperCase());
  return entry ? entry.id : null;
};

// --- Routes ---
app.get("/api/coins", (req, res) => {
  res.json(COIN_MAP);
});

app.get("/api/holdings", (req, res) => {
  const stmt = db.prepare("SELECT * FROM holdings ORDER BY id DESC");
  res.json(stmt.all());
});

app.post("/api/holdings", (req, res) => {
  const { symbol, amount, costBasis } = req.body || {};
  if (!symbol || amount == null) return res.status(400).json({ error: "symbol and amount are required" });
  const coinId = symbolToId(symbol);
  if (!coinId) return res.status(400).json({ error: "Unsupported symbol. Check /api/coins" });

  const stmt = db.prepare("INSERT INTO holdings (symbol, amount, costBasis) VALUES (?, ?, ?)");
  const info = stmt.run(symbol.toUpperCase(), Number(amount), Number(costBasis || 0));
  res.status(201).json({ id: info.lastInsertRowid, symbol: symbol.toUpperCase(), amount: Number(amount), costBasis: Number(costBasis || 0) });
});

app.put("/api/holdings/:id", (req, res) => {
  const id = Number(req.params.id);
  const { symbol, amount, costBasis } = req.body || {};
  if (!id) return res.status(400).json({ error: "Invalid id" });
  if (!symbol || amount == null) return res.status(400).json({ error: "symbol and amount are required" });
  const coinId = symbolToId(symbol);
  if (!coinId) return res.status(400).json({ error: "Unsupported symbol. Check /api/coins" });

  const stmt = db.prepare("UPDATE holdings SET symbol = ?, amount = ?, costBasis = ? WHERE id = ?");
  const info = stmt.run(symbol.toUpperCase(), Number(amount), Number(costBasis || 0), id);
  res.json({ updated: info.changes });
});

app.delete("/api/holdings/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id" });
  const stmt = db.prepare("DELETE FROM holdings WHERE id = ?");
  const info = stmt.run(id);
  res.json({ deleted: info.changes });
});

// Price proxy
app.get("/api/prices", async (req, res) => {
  const ids = (req.query.ids || "").toString();
  if (!ids) return res.status(400).json({ error: "ids query param is required" });
  try {
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(ids)}&vs_currencies=usd&include_24hr_change=true`;
    const r = await fetch(url, { headers: { "accept": "application/json" } });
    const data = await r.json();
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch prices", details: String(e) });
  }
});

app.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
});
