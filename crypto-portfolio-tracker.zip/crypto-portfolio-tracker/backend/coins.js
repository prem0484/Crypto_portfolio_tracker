// Simple symbol → CoinGecko id map for popular coins.
// Extend this list as needed.
export const COIN_MAP = [
  { symbol: "BTC", id: "bitcoin" },
  { symbol: "ETH", id: "ethereum" },
  { symbol: "BNB", id: "binancecoin" },
  { symbol: "XRP", id: "ripple" },
  { symbol: "DOGE", id: "dogecoin" },
  { symbol: "SOL", id: "solana" },
  { symbol: "ADA", id: "cardano" },
  { symbol: "MATIC", id: "polygon-pos" },
  { symbol: "DOT", id: "polkadot" },
  { symbol: "LTC", id: "litecoin" },
  { symbol: "SHIB", id: "shiba-inu" }
];
