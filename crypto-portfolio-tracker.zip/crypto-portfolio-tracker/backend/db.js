import Database from "better-sqlite3";

const db = new Database("portfolio.db");
db.pragma("journal_mode = WAL");

// Create table if not exists
db.exec(`
  CREATE TABLE IF NOT EXISTS holdings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    amount REAL NOT NULL DEFAULT 0,
    costBasis REAL NOT NULL DEFAULT 0
  );
`);

export default db;
